# Modulos necesarios para que funcione:
1. Instalar MUI: npm install @mui/material @emotion/react @emotion/styled
2. Instalar iconos MUI: npm i @mui/icons-material
3. Instalar rutas de navegación: npm install react-router-dom
4. Instalar libreria para insertar codigo: npm i react-code-blocks