
// Rutes de l'aplicació
export const urlsApp = {
    login:"/Login",
    inici:"/",
    barraNavegacio:"/BarraNavegacio",
    carritoCompra:"",
}