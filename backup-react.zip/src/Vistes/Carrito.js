
import * as React from 'react';
import CodiBloc from '../component/CodiBloc/CodiBloc';


export default function NavegacioBarVista(props) {

  return (
    <div style={{ textAlign: "left" }}>
      <h1>Resumen pedido:</h1>
      
    </div>
  );
}