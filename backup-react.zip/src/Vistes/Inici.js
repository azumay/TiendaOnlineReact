
import * as React from 'react';
import CodiBloc from '../component/CodiBloc/CodiBloc';
import Productos from '../component/CuerpoWeb/Content';


export default function Inici(props) {
    const codi = `function Cuadro(props)
{
    const { color } = props;
}
`;
    return (

        <div style={{ textAlign: "left" }}>
            <h1>Informática</h1>
            <Productos />
        </div>
    );
}