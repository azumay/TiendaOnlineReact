import './App.css';
import React, { useState }from 'react';
import NavegacioBar from './component/NavegacioBar/NavegacioBar'
import { urlsApp } from './constants/Rutas';
import { Route, Routes } from 'react-router-dom';
import Login from './component/Login/Login'
import { ThemeProvider } from '@mui/material/styles';
import { theme } from './constants/Estils'
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import LockOpenIcon from '@mui/icons-material/LockOpen';
import LaptopChromebookIcon from '@mui/icons-material/LaptopChromebook';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import Inici from './Vistes/Inici';
import NavegacioBarVista from './Vistes/Carrito';
import Container from '@mui/material/Container';
import ProductContext from './context/ProductContext';

const elementsProba = [
  {
    nom: "Portátiles",
    icona: <LaptopChromebookIcon />,
    redireccio: urlsApp.inici
  }, {
    nom: "divider"
  }, {
    nom: "Carrito",
    icona: <ShoppingCartIcon />,
    redireccio: urlsApp.barraNavegacio
  }, {
    nom: "Login",
    icona: <LockOpenIcon />,
    redireccio: urlsApp.login
  },
];

const elementLogin =
{
  titol: "Iniciar Sessió",
  avatar: <LockOutlinedIcon />,
  redireccio: urlsApp.login
};

function App() {
  const [carreto, setCarreto] = useState([]);
  return (
    <ProductContext.Provider value={{carreto, setCarreto}}>
    <div className="App">
      <ThemeProvider theme={theme} >
        <NavegacioBar elementsMenu={elementsProba} titol="Tienda Online" >
          <Container fixed>
            <Routes>
              <Route path={urlsApp.inici} element={<Inici />} />
              <Route path={urlsApp.barraNavegacio} element={<NavegacioBarVista />} />
              <Route path={urlsApp.login} element={<Login elementsLogin={elementLogin} />} />
            </Routes>
          </Container>
        </NavegacioBar>
      </ThemeProvider>
    </div>
    </ProductContext.Provider>
  );
}

export default App;
